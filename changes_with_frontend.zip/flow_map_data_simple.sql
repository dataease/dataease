-- Create flow map data table
CREATE TABLE IF NOT EXISTS flow_map_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    source_city VARCHAR(50) NOT NULL,
    source_province VARCHAR(50) NOT NULL,
    source_longitude DECIMAL(10, 6) NOT NULL,
    source_latitude DECIMAL(10, 6) NOT NULL,
    target_city VARCHAR(50) NOT NULL,
    target_province VARCHAR(50) NOT NULL,
    target_longitude DECIMAL(10, 6) NOT NULL,
    target_latitude DECIMAL(10, 6) NOT NULL,
    flow_value BIGINT NOT NULL,
    flow_type VARCHAR(20) NOT NULL,
    flow_category VARCHAR(50) NOT NULL,
    created_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert flow data
INSERT INTO flow_map_data (source_city, source_province, source_longitude, source_latitude, target_city, target_province, target_longitude, target_latitude, flow_value, flow_type, flow_category) VALUES
-- Major city flows
('北京市', '北京市', 116.4074, 39.9042, '上海市', '上海市', 121.4737, 31.2304, 150000, 'population', 'major_cities'),
('上海市', '上海市', 121.4737, 31.2304, '北京市', '北京市', 116.4074, 39.9042, 120000, 'population', 'major_cities'),
('北京市', '北京市', 116.4074, 39.9042, '深圳市', '广东省', 114.0579, 22.5431, 80000, 'population', 'major_cities'),
('深圳市', '广东省', 114.0579, 22.5431, '北京市', '北京市', 116.4074, 39.9042, 60000, 'population', 'major_cities'),
('上海市', '上海市', 121.4737, 31.2304, '深圳市', '广东省', 114.0579, 22.5431, 70000, 'population', 'major_cities'),
('深圳市', '广东省', 114.0579, 22.5431, '上海市', '上海市', 121.4737, 31.2304, 50000, 'population', 'major_cities'),
('广州市', '广东省', 113.2644, 23.1291, '深圳市', '广东省', 114.0579, 22.5431, 90000, 'population', 'guangdong'),
('深圳市', '广东省', 114.0579, 22.5431, '广州市', '广东省', 113.2644, 23.1291, 75000, 'population', 'guangdong'),

-- Provincial capitals to major cities
('成都市', '四川省', 104.0668, 30.5728, '北京市', '北京市', 116.4074, 39.9042, 45000, 'population', 'capital_to_major'),
('成都市', '四川省', 104.0668, 30.5728, '上海市', '上海市', 121.4737, 31.2304, 35000, 'population', 'capital_to_major'),
('成都市', '四川省', 104.0668, 30.5728, '深圳市', '广东省', 114.0579, 22.5431, 40000, 'population', 'capital_to_major'),
('武汉市', '湖北省', 114.2986, 30.5844, '北京市', '北京市', 116.4074, 39.9042, 30000, 'population', 'capital_to_major'),
('武汉市', '湖北省', 114.2986, 30.5844, '上海市', '上海市', 121.4737, 31.2304, 25000, 'population', 'capital_to_major'),
('武汉市', '湖北省', 114.2986, 30.5844, '深圳市', '广东省', 114.0579, 22.5431, 28000, 'population', 'capital_to_major'),
('西安市', '陕西省', 108.9402, 34.3416, '北京市', '北京市', 116.4074, 39.9042, 20000, 'population', 'capital_to_major'),
('西安市', '陕西省', 108.9402, 34.3416, '上海市', '上海市', 121.4737, 31.2304, 18000, 'population', 'capital_to_major'),
('西安市', '陕西省', 108.9402, 34.3416, '深圳市', '广东省', 114.0579, 22.5431, 22000, 'population', 'capital_to_major'),
('郑州市', '河南省', 113.6254, 34.7466, '北京市', '北京市', 116.4074, 39.9042, 25000, 'population', 'capital_to_major'),
('郑州市', '河南省', 113.6254, 34.7466, '上海市', '上海市', 121.4737, 31.2304, 20000, 'population', 'capital_to_major'),
('郑州市', '河南省', 113.6254, 34.7466, '深圳市', '广东省', 114.0579, 22.5431, 23000, 'population', 'capital_to_major'),

-- Yangtze River Delta flows
('南京市', '江苏省', 118.7674, 32.0415, '上海市', '上海市', 121.4737, 31.2304, 60000, 'population', 'yangtze_delta'),
('上海市', '上海市', 121.4737, 31.2304, '南京市', '江苏省', 118.7674, 32.0415, 45000, 'population', 'yangtze_delta'),
('杭州市', '浙江省', 120.1551, 30.2741, '上海市', '上海市', 121.4737, 31.2304, 55000, 'population', 'yangtze_delta'),
('上海市', '上海市', 121.4737, 31.2304, '杭州市', '浙江省', 120.1551, 30.2741, 40000, 'population', 'yangtze_delta'),
('苏州市', '江苏省', 120.5853, 31.2989, '上海市', '上海市', 121.4737, 31.2304, 50000, 'population', 'yangtze_delta'),
('上海市', '上海市', 121.4737, 31.2304, '苏州市', '江苏省', 120.5853, 31.2989, 35000, 'population', 'yangtze_delta'),
('无锡市', '江苏省', 120.3019, 31.4912, '上海市', '上海市', 121.4737, 31.2304, 30000, 'population', 'yangtze_delta'),
('上海市', '上海市', 121.4737, 31.2304, '无锡市', '江苏省', 120.3019, 31.4912, 25000, 'population', 'yangtze_delta'),
('宁波市', '浙江省', 121.5440, 29.8683, '上海市', '上海市', 121.4737, 31.2304, 35000, 'population', 'yangtze_delta'),
('上海市', '上海市', 121.4737, 31.2304, '宁波市', '浙江省', 121.5440, 29.8683, 28000, 'population', 'yangtze_delta'),

-- Pearl River Delta flows
('东莞市', '广东省', 113.7463, 23.0223, '深圳市', '广东省', 114.0579, 22.5431, 60000, 'population', 'pearl_delta'),
('深圳市', '广东省', 114.0579, 22.5431, '东莞市', '广东省', 113.7463, 23.0223, 45000, 'population', 'pearl_delta'),
('佛山市', '广东省', 113.1227, 23.0288, '广州市', '广东省', 113.2644, 23.1291, 40000, 'population', 'pearl_delta'),
('广州市', '广东省', 113.2644, 23.1291, '佛山市', '广东省', 113.1227, 23.0288, 35000, 'population', 'pearl_delta'),
('中山市', '广东省', 113.3824, 22.5211, '深圳市', '广东省', 114.0579, 22.5431, 25000, 'population', 'pearl_delta'),
('深圳市', '广东省', 114.0579, 22.5431, '中山市', '广东省', 113.3824, 22.5211, 20000, 'population', 'pearl_delta'),
('珠海市', '广东省', 113.5538, 22.2569, '深圳市', '广东省', 114.0579, 22.5431, 30000, 'population', 'pearl_delta'),
('深圳市', '广东省', 114.0579, 22.5431, '珠海市', '广东省', 113.5538, 22.2569, 25000, 'population', 'pearl_delta'),

-- Beijing-Tianjin-Hebei flows
('天津市', '天津市', 117.2008, 39.0842, '北京市', '北京市', 116.4074, 39.9042, 80000, 'population', 'jingjinji'),
('北京市', '北京市', 116.4074, 39.9042, '天津市', '天津市', 117.2008, 39.0842, 60000, 'population', 'jingjinji'),
('石家庄市', '河北省', 114.5025, 38.0455, '北京市', '北京市', 116.4074, 39.9042, 50000, 'population', 'jingjinji'),
('北京市', '北京市', 116.4074, 39.9042, '石家庄市', '河北省', 114.5025, 38.0455, 35000, 'population', 'jingjinji'),

-- Chengdu-Chongqing flows
('成都市', '四川省', 104.0668, 30.5728, '重庆市', '重庆市', 106.5516, 29.5630, 60000, 'population', 'chengyu'),
('重庆市', '重庆市', 106.5516, 29.5630, '成都市', '四川省', 104.0668, 30.5728, 50000, 'population', 'chengyu'),

-- Northeast flows
('沈阳市', '辽宁省', 123.4315, 41.8057, '大连市', '辽宁省', 121.6147, 38.9140, 35000, 'population', 'northeast'),
('大连市', '辽宁省', 121.6147, 38.9140, '沈阳市', '辽宁省', 123.4315, 41.8057, 30000, 'population', 'northeast'),
('长春市', '吉林省', 125.3245, 43.8868, '沈阳市', '辽宁省', 123.4315, 41.8057, 25000, 'population', 'northeast'),
('沈阳市', '辽宁省', 123.4315, 41.8057, '长春市', '吉林省', 125.3245, 43.8868, 20000, 'population', 'northeast'),
('哈尔滨市', '黑龙江省', 126.6425, 45.7569, '长春市', '吉林省', 125.3245, 43.8868, 20000, 'population', 'northeast'),
('长春市', '吉林省', 125.3245, 43.8868, '哈尔滨市', '黑龙江省', 126.6425, 45.7569, 18000, 'population', 'northeast'),

-- Central region flows
('武汉市', '湖北省', 114.2986, 30.5844, '长沙市', '湖南省', 112.9823, 28.1949, 30000, 'population', 'central'),
('长沙市', '湖南省', 112.9823, 28.1949, '武汉市', '湖北省', 114.2986, 30.5844, 25000, 'population', 'central'),
('郑州市', '河南省', 113.6254, 34.7466, '武汉市', '湖北省', 114.2986, 30.5844, 20000, 'population', 'central'),
('武汉市', '湖北省', 114.2986, 30.5844, '郑州市', '河南省', 113.6254, 34.7466, 18000, 'population', 'central'),
('合肥市', '安徽省', 117.2272, 31.8206, '南京市', '江苏省', 118.7674, 32.0415, 25000, 'population', 'central'),
('南京市', '江苏省', 118.7674, 32.0415, '合肥市', '安徽省', 117.2272, 31.8206, 20000, 'population', 'central'),

-- Western region flows
('西安市', '陕西省', 108.9402, 34.3416, '成都市', '四川省', 104.0668, 30.5728, 20000, 'population', 'western'),
('成都市', '四川省', 104.0668, 30.5728, '西安市', '陕西省', 108.9402, 34.3416, 18000, 'population', 'western'),
('兰州市', '甘肃省', 103.8236, 36.0581, '西安市', '陕西省', 108.9402, 34.3416, 15000, 'population', 'western'),
('西安市', '陕西省', 108.9402, 34.3416, '兰州市', '甘肃省', 103.8236, 36.0581, 12000, 'population', 'western'),
('西宁市', '青海省', 101.7782, 36.6232, '兰州市', '甘肃省', 103.8236, 36.0581, 10000, 'population', 'western'),
('兰州市', '甘肃省', 103.8236, 36.0581, '西宁市', '青海省', 101.7782, 36.6232, 8000, 'population', 'western'),

-- Trade flows
('上海市', '上海市', 121.4737, 31.2304, '深圳市', '广东省', 114.0579, 22.5431, 500000, 'trade', 'trade_flow'),
('深圳市', '广东省', 114.0579, 22.5431, '上海市', '上海市', 121.4737, 31.2304, 450000, 'trade', 'trade_flow'),
('北京市', '北京市', 116.4074, 39.9042, '上海市', '上海市', 121.4737, 31.2304, 300000, 'trade', 'trade_flow'),
('上海市', '上海市', 121.4737, 31.2304, '北京市', '北京市', 116.4074, 39.9042, 280000, 'trade', 'trade_flow'),
('广州市', '广东省', 113.2644, 23.1291, '深圳市', '广东省', 114.0579, 22.5431, 200000, 'trade', 'trade_flow'),
('深圳市', '广东省', 114.0579, 22.5431, '广州市', '广东省', 113.2644, 23.1291, 180000, 'trade', 'trade_flow'),

-- Finance flows
('北京市', '北京市', 116.4074, 39.9042, '上海市', '上海市', 121.4737, 31.2304, 800000, 'finance', 'finance_flow'),
('上海市', '上海市', 121.4737, 31.2304, '北京市', '北京市', 116.4074, 39.9042, 750000, 'finance', 'finance_flow'),
('深圳市', '广东省', 114.0579, 22.5431, '上海市', '上海市', 121.4737, 31.2304, 600000, 'finance', 'finance_flow'),
('上海市', '上海市', 121.4737, 31.2304, '深圳市', '广东省', 114.0579, 22.5431, 550000, 'finance', 'finance_flow'),
('广州市', '广东省', 113.2644, 23.1291, '深圳市', '广东省', 114.0579, 22.5431, 400000, 'finance', 'finance_flow'),
('深圳市', '广东省', 114.0579, 22.5431, '广州市', '广东省', 113.2644, 23.1291, 350000, 'finance', 'finance_flow');

-- Create indexes
CREATE INDEX idx_source_city ON flow_map_data(source_city);
CREATE INDEX idx_target_city ON flow_map_data(target_city);
CREATE INDEX idx_flow_type ON flow_map_data(flow_type);
CREATE INDEX idx_flow_category ON flow_map_data(flow_category);
